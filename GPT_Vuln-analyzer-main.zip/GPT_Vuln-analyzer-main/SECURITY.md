# Security Policy

## Supported Versions

Supports all Python3.10 using OS with also nmap installed

If any security issues found they can be patched and added as a merge request
